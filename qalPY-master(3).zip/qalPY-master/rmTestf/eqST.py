#!/usr/bin/python
def eqSt(stw):
	len(stw)
	listW = []
	listW.append(stw)
	for i in listW:
		if len(i) >= len(stw):
                	x = len(stw) + len(i)
                	print x
			print str(" "*5+i)

eqSt('stwooooo')

